# BHASHA-MITRA 🇮🇳

**Vernacular Pedagogy and Real-Time Translation Tool for Mother Tongue Based Primary Education.**

BHASHA-MITRA helps primary-school children understand educational concepts in their mother tongue through real-time voice translation, AI explanations, visual learning, and personalized quizzes — built for children, teachers, and parents in India.

## ✨ Core experience

The app is **not** a simple translator. The end-to-end workflow is:

```
Teacher/Student Voice → Speech Recognition → Language Detection → Translation
→ Child-Friendly Explanation → Text + Voice → Interactive Quiz → Performance Tracking
```

## 🗣️ Languages supported

English, Hindi, Kannada, Telugu, Tamil, Malayalam, Marathi, Bengali.
Add a new language by appending one entry to `src/lib/languages.js` — it becomes available app-wide.

Each learner selects a **mother tongue**, **learning language**, and **interface language**.

## 📱 Screens

- **Home** — student persona, daily streak, today's progress, Talk & Learn quick card, continue learning, subject ribbon, recommended practice.
- **Learn** — Mathematics, Science, EVS, English, General Knowledge; each lesson has a simple explanation, Indian-life example, mother-tongue translation, audio, "Explain Again", and an AI tutor.
- **Talk & Learn** — speak or type a question → speech-to-text → AI explanation → mother-tongue translation → audio playback.
- **Scan & Explain** — photograph/upload a textbook page → OCR → simple explanation → mother-tongue translation → audio → quiz.
- **Live Translator** — two-way teacher/student conversation with transcripts, translation, TTS, and history.
- **Quiz** — AI-generated MCQ / true-false questions per lesson, scoring, mistake review, progress saved.
- **Teacher Dashboard** — student count, average performance, students needing attention, most-difficult concepts, lesson completion, language distribution.
- **Parent View** — learning time, lessons completed, quiz performance, improvement area, recommended activity.

## 🤖 AI Vernacular Tutor

Age-appropriate, encouraging, uses Indian examples, supports all listed languages, remembers lesson context, asks follow-up questions, and never shames a wrong answer. Quick actions: *Explain Simply · Give Example · Explain in My Language · Show Another Example · Ask Me a Question*.

## 🎯 Personalized learning

Tracks quiz scores, wrong answers, completed lessons, time spent, and difficult concepts. A simple recommendation engine suggests the weakest subject for extra practice — no complex ML exposed to children.

## 🔌 Offline-first

- Live Online/Offline badge (browser connectivity).
- Lessons are stored as entities and cached by the SDK; progress is saved locally and synced when online.
- Quizzes can be taken once generated.
- **Note:** AI translation, speech, and OCR require connectivity — the app shows clear processing states and never fakes offline AI.

## 🛠️ Tech stack (as built on Base44)

- **Frontend:** React + Tailwind CSS, responsive (mobile bottom-nav + desktop rail).
- **Backend:** Base44 serverless functions (`base44/functions/`).
- **Database:** Base44 entities — `StudentProfile`, `Lesson`, `QuizAttempt`, `StudentProgress`, `ConversationHistory`.
- **Auth:** Built-in Base44 authentication (login/register/reset).
- **AI / Speech / Translation / OCR / TTS:** Base44 Core integrations (`InvokeLLM`, `TranscribeAudio`, `GenerateSpeech`, `ExtractDataFromUploadedFile`) invoked through scoped backend functions.

### Backend functions
| Function | Purpose |
|---|---|
| `aiExplain` | Child-friendly explanation + mother-tongue translation + follow-up (AI tutor) |
| `aiQuiz` | Generate age-appropriate quiz questions for a lesson |
| `transcribeAudio` | Speech-to-text for Indian languages |
| `speak` | Text-to-speech in Indian languages |
| `ocrExplain` | OCR an image, simplify and translate the content |
| `translate` | Direct two-way translation for the live translator |

## 🎬 Hackathon demo flow

1. Open the app → select **Aarav** (Kannada mother tongue, Class 3) on the onboarding screen.
2. Tap **Learn → Science → "Why the Moon Changes Shape"**.
3. Tap **Translate** to hear the explanation in Kannada, then **Listen**.
4. Tap **Talk & Learn**, type or speak *"Why does the moon change its shape?"*, and hear the Kannada answer.
5. Tap **Test My Understanding** → take the quiz → see the score.
6. Open **Teacher Dashboard** to see class performance, difficult concepts, and students needing attention.
7. Open **Parent View** for Aarav's learning summary.

Two demo students are seeded: **Aarav** (Kannada) and **Priya** (Tamil), along with 10 sample lessons across all five subjects.

## 🔒 Safety

- No unnecessary personal data collected.
- Voice and image uploads are stored **privately** with short-lived signed URLs.
- AI prompts enforce age-appropriate, encouraging, non-shaming responses.
- Clear error messages for mic/camera permission denial, empty input, and API failures.

## 🚀 Setup

The app runs on the Base44 platform — no separate server setup is required. Publish the app to get a live URL. All AI, speech, translation, OCR, and TTS features work out of the box using built-in integrations.

## 🧭 Deferred for later

- Downloadable lesson packs with full offline AI models.
- Image-based and voice-answered quiz questions.
- Teacher PDF upload + AI lesson generation + assignment workflow.
- WebSocket-based streaming speech recognition.