import React from "react";
import { Languages } from "lucide-react";

export default function AuthLayout({ title, subtitle, footer, children }) {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-orange-50/70 via-background to-blue-50/40">
      <header className="px-6 pt-7 pb-1 flex items-center justify-center gap-2.5">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-orange-500 to-blue-600 flex items-center justify-center shadow-sm">
          <Languages className="w-5 h-5 text-white" aria-hidden="true" />
        </div>
        <div className="leading-none">
          <span className="font-heading text-lg font-bold tracking-tight text-foreground">BHASHA-MITRA</span>
          <p className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground mt-0.5">Vernacular Learning</p>
        </div>
      </header>

      <div className="flex-1 flex items-center justify-center px-4 py-6">
        <div className="w-full max-w-md">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-heading font-bold tracking-tight text-foreground">{title}</h1>
            {subtitle && <p className="text-muted-foreground mt-1.5 text-sm">{subtitle}</p>}
          </div>
          <div className="bg-card rounded-3xl shadow-lg shadow-orange-500/5 border border-border/70 p-6 sm:p-8">
            {children}
          </div>
          {footer && <p className="text-center text-sm text-muted-foreground mt-6">{footer}</p>}
        </div>
      </div>

      <footer className="px-6 pb-6 text-center text-[11px] text-muted-foreground">
        Mother-tongue based learning for every child · Made in India
      </footer>
    </div>
  );
}