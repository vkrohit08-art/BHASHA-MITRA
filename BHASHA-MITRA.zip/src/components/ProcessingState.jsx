import React from 'react';
import { Loader2 } from 'lucide-react';

const LABELS = {
  listening: 'Listening…',
  understanding: 'Understanding…',
  translating: 'Translating…',
  explaining: 'Generating explanation…',
  speaking: 'Speaking…',
  scanning: 'Scanning image…',
  reading: 'Reading text…',
  generating: 'Generating quiz…',
  grading: 'Checking answers…',
};

export default function ProcessingState({ stage, hint }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-3xl border-2 border-dashed border-[#E2E8F0] bg-[#F8FAFC] px-6 py-10 text-center">
      <Loader2 className="h-8 w-8 animate-spin text-[#FF7A00]" />
      <p className="font-display text-lg font-semibold text-[#0F172A]">{LABELS[stage] || 'Working…'}</p>
      {hint && <p className="text-sm text-slate-500">{hint}</p>}
    </div>
  );
}