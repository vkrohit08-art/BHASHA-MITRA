const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useRef, useState } from 'react';
import { Volume2, Loader2 } from 'lucide-react';

import { cn } from '@/lib/utils';

// Fetches TTS for the given text + language and plays it.
export default function AudioPlayer({ text, languageCode, label = 'Listen', className, variant = 'saffron' }) {
  const [audioUrl, setAudioUrl] = useState(null);
  const [loading, setLoading] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [error, setError] = useState('');
  const audioRef = useRef(null);

  const styles = {
    saffron: 'bg-[#FF7A00] text-white',
    royal: 'bg-[#2563EB] text-white',
    jade: 'bg-[#10B981] text-white',
    purple: 'bg-[#8B5CF6] text-white',
    ghost: 'bg-white text-[#0F172A] border-2 border-[#E2E8F0]',
  };

  const generate = async () => {
    if (audioUrl) {
      audioRef.current?.play();
      return;
    }
    setLoading(true);
    setError('');
    try {
      const res = await db.functions.invoke('speak', { text, languageCode });
      setAudioUrl(res.data.audioUrl);
    } catch (e) {
      setError(e.message || 'Audio failed');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (audioUrl && audioRef.current) {
      audioRef.current.play();
    }
  }, [audioUrl]);

  return (
    <div className={cn('inline-flex items-center', className)}>
      <button
        onClick={generate}
        disabled={loading || !text}
        className={cn('inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-bold disabled:opacity-50', styles[variant])}
      >
        {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Volume2 className="h-4 w-4" />}
        {loading ? 'Speaking…' : playing ? 'Playing…' : `🔊 ${label}`}
      </button>
      {error && <span className="ml-2 text-xs text-[#FF7A00]">{error}</span>}
      {audioUrl && (
        <audio
          ref={audioRef}
          src={audioUrl}
          onPlay={() => setPlaying(true)}
          onEnded={() => setPlaying(false)}
          onPause={() => setPlaying(false)}
          className="hidden"
        />
      )}
    </div>
  );
}