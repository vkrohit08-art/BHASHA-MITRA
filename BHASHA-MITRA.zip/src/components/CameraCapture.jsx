import React, { useRef, useState, useEffect, useCallback } from 'react';
import { X, RefreshCw, Check, Loader2, AlertTriangle } from 'lucide-react';

export default function CameraCapture({ onCapture, onClose }) {
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const [error, setError] = useState('');
  const [starting, setStarting] = useState(true);
  const [shot, setShot] = useState(null);

  const stopStream = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
  }, []);

  const startCamera = useCallback(async () => {
    setStarting(true);
    setError('');
    try {
      if (!navigator.mediaDevices?.getUserMedia) {
        throw new Error('Camera is not supported on this device. Use Upload Image instead.');
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' }, width: { ideal: 1920 }, height: { ideal: 1080 } },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {});
      }
    } catch (e) {
      if (e?.name === 'NotAllowedError') {
        setError('Camera permission was blocked. Allow access in your browser, or use Upload Image.');
      } else {
        setError(e?.message || 'Could not open the camera. Use Upload Image instead.');
      }
    } finally {
      setStarting(false);
    }
  }, []);

  useEffect(() => {
    startCamera();
    return () => stopStream();
  }, [startCamera, stopStream]);

  const capture = () => {
    const video = videoRef.current;
    if (!video || !video.videoWidth) return;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
    canvas.toBlob((blob) => {
      if (!blob) return;
      setShot(blob);
      stopStream();
    }, 'image/jpeg', 0.92);
  };

  const retake = () => { setShot(null); startCamera(); };

  const usePhoto = () => {
    if (!shot) return;
    const file = new File([shot], `scan-${Date.now()}.jpg`, { type: 'image/jpeg' });
    onCapture(file);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col">
      <div className="flex items-center justify-between px-4 py-3 text-white">
        <button onClick={() => { stopStream(); onClose?.(); }} className="p-2 -ml-2 rounded-full hover:bg-white/10" aria-label="Close camera">
          <X className="h-6 w-6" />
        </button>
        <span className="font-display font-semibold text-sm">Scan Textbook Page</span>
        <div className="w-10" />
      </div>

      <div className="relative flex-1 overflow-hidden bg-black">
        <video ref={videoRef} playsInline muted className="absolute inset-0 h-full w-full object-cover" />

        {!shot && !starting && !error && (
          <>
            <div className="pointer-events-none absolute inset-0 flex items-center justify-center p-6">
              <div className="w-[86%] aspect-[3/4] rounded-2xl border-2 border-white/80 shadow-[0_0_0_9999px_rgba(0,0,0,0.5)]" />
            </div>
            <div className="pointer-events-none absolute top-4 left-0 right-0 flex justify-center gap-6">
              <span className="h-2 w-2 rounded-full bg-white/70 animate-pulse" />
            </div>
            <p className="absolute bottom-6 left-0 right-0 text-center text-white/90 text-sm font-medium px-6">
              Align the page inside the frame and hold steady
            </p>
          </>
        )}

        {starting && (
          <div className="absolute inset-0 flex items-center justify-center gap-2 text-white/85">
            <Loader2 className="h-5 w-5 animate-spin" /> Starting camera…
          </div>
        )}

        {error && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-8 text-center text-white">
            <AlertTriangle className="h-8 w-8 text-orange-400" />
            <p className="text-sm max-w-xs">{error}</p>
            <button onClick={onClose} className="mt-2 rounded-full bg-white text-slate-900 px-5 py-2 text-sm font-semibold">
              Go back
            </button>
          </div>
        )}

        {shot && (
          <img src={URL.createObjectURL(shot)} alt="capture" className="absolute inset-0 h-full w-full object-contain" />
        )}
      </div>

      {!error && (
        <div className="bg-black px-6 py-6 flex items-center justify-center gap-10">
          {!shot ? (
            <button onClick={capture} disabled={starting} className="flex flex-col items-center gap-1.5 text-white disabled:opacity-40">
              <span className="flex h-16 w-16 items-center justify-center rounded-full border-4 border-white">
                <span className="h-12 w-12 rounded-full bg-white" />
              </span>
              <span className="text-xs">Capture</span>
            </button>
          ) : (
            <>
              <button onClick={retake} className="flex flex-col items-center gap-1.5 text-white">
                <span className="flex h-12 w-12 items-center justify-center rounded-full bg-white/15">
                  <RefreshCw className="h-5 w-5" />
                </span>
                <span className="text-xs">Retake</span>
              </button>
              <button onClick={usePhoto} className="flex flex-col items-center gap-1.5 text-white">
                <span className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500">
                  <Check className="h-7 w-7" />
                </span>
                <span className="text-xs font-semibold">Use Photo</span>
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
}