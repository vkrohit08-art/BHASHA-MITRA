import React, { useState } from 'react';
import { Outlet, NavLink, useNavigate, useLocation } from 'react-router-dom';
import { Home, BookOpen, Languages, Trophy, GraduationCap, User, Mic, Wifi, WifiOff, Menu, Camera } from 'lucide-react';
import { useStudent } from '@/lib/StudentContext';
import { useOnline } from '@/lib/useOnline';
import { getLanguage } from '@/lib/languages';
import { cn } from '@/lib/utils';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle,
} from '@/components/ui/sheet';

const NAV = [
  { to: '/', label: 'Home', icon: Home, end: true },
  { to: '/learn', label: 'Learn', icon: BookOpen },
  { to: '/translate', label: 'Live Translate', icon: Languages },
  { to: '/quiz', label: 'Quiz', icon: Trophy },
];

function OnlineBadge() {
  const online = useOnline();
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold',
        online ? 'bg-[#10B981]/10 text-[#10B981]' : 'bg-[#FF7A00]/10 text-[#FF7A00]'
      )}
    >
      {online ? <Wifi className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5" />}
      {online ? 'Online' : 'Offline'}
    </span>
  );
}

function PersonaCard({ onSwitch }) {
  const { current } = useStudent();
  if (!current) return null;
  const mt = getLanguage(current.mother_tongue);
  return (
    <div className="rounded-3xl border-2 border-[#E2E8F0] bg-white p-5 shadow-[0_8px_24px_-4px_rgba(255,122,0,0.12)]">
      <div className="flex items-center gap-3">
        <div
          className="flex h-14 w-14 items-center justify-center rounded-2xl text-2xl font-bold text-white"
          style={{ backgroundColor: current.avatar_color || '#FF7A00' }}
        >
          {current.name?.charAt(0)?.toUpperCase() || 'S'}
        </div>
        <div className="min-w-0">
          <p className="truncate font-display text-lg font-semibold text-[#0F172A]">{current.name}</p>
          <p className="text-sm font-medium text-slate-500">{current.grade}</p>
        </div>
      </div>
      <div className="mt-4 flex items-center justify-between rounded-2xl bg-[#F8FAFC] px-3 py-2">
        <span className="text-xs font-semibold text-slate-500">Mother Tongue</span>
        <span className="rounded-full bg-white px-3 py-1 text-sm font-bold text-[#0F172A] shadow-sm">
          {mt.native} · {mt.name}
        </span>
      </div>
      <button
        onClick={onSwitch}
        className="mt-3 w-full rounded-2xl border-2 border-[#E2E8F0] py-2 text-sm font-bold text-[#2563EB] hover:bg-[#F8FAFC]"
      >
        Switch Student
      </button>
    </div>
  );
}

function NavPill({ to, end, children }) {
  return (
    <NavLink
      to={to}
      end={end}
      className={({ isActive }) =>
        cn(
          'flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-bold transition',
          isActive ? 'bg-[#FF7A00] text-white shadow-[0_8px_24px_-4px_rgba(255,122,0,0.4)]' : 'text-[#0F172A] hover:bg-[#F8FAFC]'
        )
      }
    >
      {children}
    </NavLink>
  );
}

export default function AppLayout() {
  const { current } = useStudent();
  const navigate = useNavigate();
  const location = useLocation();
  const [moreOpen, setMoreOpen] = useState(false);
  const isTalk = location.pathname.startsWith('/talk');

  const switchStudent = () => navigate('/onboarding');

  return (
    <div className="min-h-screen bg-[#FFFFFF] text-[#0F172A]">
      {/* Desktop left rail */}
      <aside className="fixed inset-y-0 left-0 hidden w-80 flex-col gap-4 border-r-2 border-[#E2E8F0] bg-[#F8FAFC] p-5 lg:flex">
        <div className="flex items-center justify-between px-1">
          <span className="font-display text-2xl font-bold text-[#FF7A00]">BHASHA-MITRA</span>
        </div>
        <PersonaCard onSwitch={switchStudent} />
        <div className="mt-1"><OnlineBadge /></div>
        <nav className="mt-2 flex flex-col gap-1.5">
          {NAV.map((n) => (
            <NavPill key={n.to} to={n.to} end={n.end}>
              <n.icon className="h-5 w-5" /> {n.label}
            </NavPill>
          ))}
          <NavPill to="/teacher"><GraduationCap className="h-5 w-5" /> Teacher Dashboard</NavPill>
          <NavPill to="/parent"><User className="h-5 w-5" /> Parent View</NavPill>
        </nav>
        <div className="mt-auto rounded-2xl bg-white p-3 text-center text-xs font-medium text-slate-400">
          Mother Tongue Based Learning 🇮🇳
        </div>
      </aside>

      {/* Mobile header */}
      <header className="sticky top-0 z-30 flex items-center justify-between border-b-2 border-[#E2E8F0] bg-white px-4 py-3 lg:hidden">
        <button onClick={switchStudent} className="flex items-center gap-2">
          <span
            className="flex h-9 w-9 items-center justify-center rounded-xl text-lg font-bold text-white"
            style={{ backgroundColor: current?.avatar_color || '#FF7A00' }}
          >
            {current?.name?.charAt(0)?.toUpperCase() || 'S'}
          </span>
          <span className="font-display text-lg font-bold text-[#FF7A00]">BHASHA-MITRA</span>
        </button>
        <OnlineBadge />
      </header>

      {/* Main content */}
      <main className="lg:pl-80">
        <div className="mx-auto w-full max-w-5xl px-4 pb-28 pt-4 lg:px-8 lg:pb-12">
          <Outlet />
        </div>
      </main>

      {/* Mobile bottom nav + floating mic */}
      <nav className="fixed inset-x-0 bottom-0 z-30 flex items-center justify-around border-t-2 border-[#E2E8F0] bg-white px-2 py-2 lg:hidden">
        {NAV.slice(0, 2).map((n) => (
          <NavLink key={n.to} to={n.to} end={n.end} className="flex flex-col items-center gap-0.5 px-3 py-1 text-[0.7rem] font-bold text-[#0F172A]">
            <n.icon className="h-5 w-5" /> {n.label}
          </NavLink>
        ))}
        <button
          onClick={() => navigate('/talk')}
          aria-label="Talk and Learn"
          className={cn(
            'flex h-14 w-14 -translate-y-3 items-center justify-center rounded-full bg-[#FF7A00] text-white shadow-[0_8px_24px_-4px_rgba(255,122,0,0.5)]',
            isTalk && 'ring-4 ring-[#FF7A00]/30'
          )}
        >
          <Mic className="h-6 w-6" />
        </button>
        <NavLink to="/quiz" className="flex flex-col items-center gap-0.5 px-3 py-1 text-[0.7rem] font-bold text-[#0F172A]">
          <Trophy className="h-5 w-5" /> Quiz
        </NavLink>
        <button onClick={() => setMoreOpen(true)} className="flex flex-col items-center gap-0.5 px-3 py-1 text-[0.7rem] font-bold text-[#0F172A]">
          <Menu className="h-5 w-5" /> More
        </button>
      </nav>

      <Sheet open={moreOpen} onOpenChange={setMoreOpen}>
        <SheetContent side="bottom" className="rounded-t-3xl">
          <SheetHeader>
            <SheetTitle className="font-display text-xl text-[#0F172A]">More</SheetTitle>
          </SheetHeader>
          <div className="grid grid-cols-2 gap-3 p-4 pb-8">
            <button onClick={() => { setMoreOpen(false); navigate('/translate'); }} className="flex flex-col items-center gap-2 rounded-2xl border-2 border-[#E2E8F0] p-4 font-bold text-[#2563EB]">
              <Languages className="h-6 w-6" /> Live Translate
            </button>
            <button onClick={() => { setMoreOpen(false); navigate('/teacher'); }} className="flex flex-col items-center gap-2 rounded-2xl border-2 border-[#E2E8F0] p-4 font-bold text-[#10B981]">
              <GraduationCap className="h-6 w-6" /> Teacher
            </button>
            <button onClick={() => { setMoreOpen(false); navigate('/parent'); }} className="flex flex-col items-center gap-2 rounded-2xl border-2 border-[#E2E8F0] p-4 font-bold text-[#8B5CF6]">
              <User className="h-6 w-6" /> Parent
            </button>
            <button onClick={() => { setMoreOpen(false); navigate('/scan'); }} className="flex flex-col items-center gap-2 rounded-2xl border-2 border-[#E2E8F0] p-4 font-bold text-[#FF7A00]">
              <Camera className="h-6 w-6" /> Scan & Explain
            </button>
            <button onClick={() => { setMoreOpen(false); switchStudent(); }} className="col-span-2 flex items-center justify-center gap-2 rounded-2xl bg-[#F8FAFC] p-4 font-bold text-[#0F172A]">
              Switch Student
            </button>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}