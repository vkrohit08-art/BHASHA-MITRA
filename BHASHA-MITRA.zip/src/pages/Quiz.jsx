const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

import { useStudent } from '@/lib/StudentContext';
import { getLanguage, SUBJECTS, getSubject } from '@/lib/languages';
import ProcessingState from '@/components/ProcessingState';
import AudioPlayer from '@/components/AudioPlayer';
import { ArrowLeft, Trophy, Check, X, Loader2, RotateCcw, ArrowRight, Award } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function Quiz() {
  const { lessonId } = useParams();
  const navigate = useNavigate();
  const { current } = useStudent();
  const [lesson, setLesson] = useState(null);
  const [picker, setPicker] = useState(!lessonId);
  const [lessons, setLessons] = useState([]);
  const [questions, setQuestions] = useState([]);
  const [current_q, setCurrentQ] = useState(0);
  const [answers, setAnswers] = useState([]);
  const [selected, setSelected] = useState(null);
  const [revealed, setRevealed] = useState(false);
  const [stage, setStage] = useState(null);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');

  const mt = current ? getLanguage(current.mother_tongue) : null;

  const generate = async (lessonObj) => {
    setStage('generating'); setError(''); setQuestions([]); setCurrentQ(0); setAnswers([]); setResult(null);
    try {
      const res = await db.functions.invoke('aiQuiz', {
        topic: lessonObj.title,
        concept: lessonObj.concept,
        motherTongue: mt?.name || 'English',
        count: 5,
        grade: current?.grade || 'Class 3',
      });
      if (!res.data?.questions?.length) { setError('Could not generate quiz. Try again.'); setStage(null); return; }
      setQuestions(res.data.questions);
    } catch (e) {
      setError(e.message || 'Quiz generation failed.');
    } finally {
      setStage(null);
    }
  };

  useEffect(() => {
    if (lessonId) {
      (async () => {
        try {
          const l = await db.entities.Lesson.get(lessonId);
          setLesson(l);
          generate(l);
        } catch (e) { setError('Lesson not found.'); }
      })();
    } else {
      (async () => {
        try {
          const { items } = await db.entities.Lesson.filter({}, { sort: 'order', limit: 50, fields: ['title', 'concept', 'subject', 'difficulty'] });
          setLessons(items);
        } catch (e) { /* ignore */ }
      })();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lessonId]);

  const choose = (idx) => {
    if (revealed) return;
    setSelected(idx);
  };

  const confirm = () => {
    if (selected === null) return;
    const q = questions[current_q];
    const isCorrect = selected === q.answerIndex;
    const newAnswers = [...answers, {
      question: q.question, selected: q.options[selected], correct: q.options[q.answerIndex], is_correct: isCorrect,
    }];
    setAnswers(newAnswers);
    setRevealed(true);
  };

  const next = async () => {
    if (current_q + 1 < questions.length) {
      setCurrentQ((c) => c + 1); setSelected(null); setRevealed(false);
    } else {
      await finish();
    }
  };

  const finish = async () => {
    setStage('grading');
    const score = answers.filter((a) => a.is_correct).length;
    const total = questions.length;
    try {
      if (current && lesson) {
        await db.entities.QuizAttempt.create({
          student_id: current.id, student_name: current.name,
          lesson_id: lesson.id, lesson_title: lesson.title, subject: lesson.subject,
          score, total, answers,
        });
        // mark progress completed
        const { items } = await db.entities.StudentProgress.filter({ student_id: current.id, lesson_id: lesson.id }, { limit: 1 });
        if (items[0]) {
          await db.entities.StudentProgress.update(items[0].id, { status: 'completed' });
        } else {
          await db.entities.StudentProgress.create({ student_id: current.id, lesson_id: lesson.id, lesson_title: lesson.title, subject: lesson.subject, status: 'completed' });
        }
      }
    } catch (e) { /* ignore */ }
    db.analytics.track('quiz_completed', { lesson_id: lessonId, score, subject: lesson?.subject });
    setResult({ score, total });
    setStage(null);
  };

  const restart = () => {
    setQuestions([]); setCurrentQ(0); setAnswers([]); setSelected(null); setRevealed(false); setResult(null);
    if (lesson) generate(lesson);
  };

  // Picker (no lessonId)
  if (picker && !lessonId) {
    return (
      <div className="space-y-5">
        <div>
          <h1 className="font-display text-3xl font-bold text-[#0F172A]">Practice Quiz</h1>
          <p className="text-slate-500">Pick a lesson to test your understanding.</p>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          {lessons.map((l) => {
            const subj = getSubject(l.subject);
            return (
              <button key={l.id} onClick={() => navigate(`/quiz/${l.id}`)}
                className="flex items-center gap-3 rounded-[24px] border-2 border-[#E2E8F0] bg-white p-4 text-left hover:-translate-y-0.5"
                style={{ boxShadow: `0 8px 24px -4px ${subj.color}22` }}>
                <span className="text-2xl">{subj.icon}</span>
                <span className="flex-1"><span className="block font-bold text-[#0F172A]">{l.title}</span><span className="block text-sm text-slate-500">{l.subject}</span></span>
                <ArrowRight className="h-5 w-5 text-[#10B981]" />
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  // Result screen
  if (result) {
    const pct = Math.round((result.score / result.total) * 100);
    const good = pct >= 60;
    return (
      <div className="space-y-5">
        <div className={cn('rounded-[24px] p-8 text-center text-white', good ? 'bg-[#10B981]' : 'bg-[#FF7A00]')} style={{ boxShadow: `0 8px 24px -4px ${good ? 'rgba(16,185,129,0.4)' : 'rgba(255,122,0,0.4)'}` }}>
          <Award className="mx-auto h-12 w-12" />
          <h1 className="mt-2 font-display text-4xl font-bold">{result.score} / {result.total}</h1>
          <p className="mt-1 font-semibold text-white/90">{pct}% correct</p>
          <p className="mt-2 text-sm text-white/80">{good ? 'Great work! You understand this well. 🌟' : 'Good try! Let us revise the tricky parts together.'}</p>
        </div>

        <div className="rounded-[24px] border-2 border-[#E2E8F0] bg-white p-5">
          <h2 className="font-display text-lg font-semibold text-[#0F172A]">Review</h2>
          <div className="mt-3 space-y-3">
            {answers.map((a, i) => (
              <div key={i} className={cn('rounded-2xl border-2 p-4', a.is_correct ? 'border-[#10B981]/30 bg-[#10B981]/5' : 'border-[#FF7A00]/30 bg-[#FF7A00]/5')}>
                <div className="flex items-start gap-2">
                  {a.is_correct ? <Check className="mt-0.5 h-5 w-5 shrink-0 text-[#10B981]" /> : <X className="mt-0.5 h-5 w-5 shrink-0 text-[#FF7A00]" />}
                  <div>
                    <p className="font-semibold text-[#0F172A]">{a.question}</p>
                    {!a.is_correct && <p className="mt-1 text-sm text-[#FF7A00]">Your answer: {a.selected}</p>}
                    <p className="text-sm font-semibold text-[#10B981]">Correct: {a.correct}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex gap-3">
          <button onClick={restart} className="flex flex-1 items-center justify-center gap-2 rounded-2xl bg-[#2563EB] py-3 font-bold text-white"><RotateCcw className="h-4 w-4" /> Try Again</button>
          <button onClick={() => navigate('/')} className="flex-1 rounded-2xl border-2 border-[#E2E8F0] py-3 font-bold text-[#0F172A]">Home</button>
        </div>
      </div>
    );
  }

  // Generating
  if (stage === 'generating' || !questions.length) {
    return (
      <div className="space-y-5">
        <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-sm font-bold text-slate-500"><ArrowLeft className="h-4 w-4" /> Back</button>
        {error ? (
          <div className="rounded-2xl bg-[#FF7A00]/10 p-4 text-sm font-semibold text-[#FF7A00]">{error}</div>
        ) : (
          <ProcessingState stage="generating" hint="Creating your quiz questions…" />
        )}
      </div>
    );
  }

  // Question
  const q = questions[current_q];
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-sm font-bold text-slate-500"><ArrowLeft className="h-4 w-4" /> Exit</button>
        <span className="rounded-full bg-[#10B981]/10 px-3 py-1 text-sm font-bold text-[#10B981]">Question {current_q + 1} / {questions.length}</span>
      </div>

      <div className="rounded-[24px] border-2 border-[#E2E8F0] bg-white p-6">
        <div className="flex items-center gap-2"><Trophy className="h-5 w-5 text-[#10B981]" /><span className="text-xs font-bold uppercase text-[#10B981]">{q.type === 'truefalse' ? 'True / False' : 'Multiple Choice'}</span></div>
        <h2 className="mt-3 font-display text-2xl font-semibold text-[#0F172A]">{q.question}</h2>
        {q.translation && <p className="mt-1 text-sm text-slate-500">{q.translation}</p>}
      </div>

      <div className="grid gap-3">
        {q.options.map((opt, idx) => {
          const isAnswer = idx === q.answerIndex;
          const isChosen = idx === selected;
          let style = 'border-[#E2E8F0] bg-white hover:border-[#10B981]';
          if (revealed) {
            if (isAnswer) style = 'border-[#10B981] bg-[#10B981]/10';
            else if (isChosen) style = 'border-[#FF7A00] bg-[#FF7A00]/10';
            else style = 'border-[#E2E8F0] bg-white opacity-60';
          } else if (isChosen) {
            style = 'border-[#2563EB] bg-[#2563EB]/5';
          }
          return (
            <button key={idx} onClick={() => choose(idx)} disabled={revealed}
              className={cn('flex items-center justify-between rounded-2xl border-2 p-4 text-left text-[1.0625rem] font-semibold text-[#0F172A] transition', style)}>
              <span>{opt}</span>
              {revealed && isAnswer && <Check className="h-5 w-5 text-[#10B981]" />}
              {revealed && isChosen && !isAnswer && <X className="h-5 w-5 text-[#FF7A00]" />}
            </button>
          );
        })}
      </div>

      {revealed && (
        <div className="rounded-2xl bg-[#F8FAFC] p-4">
          <p className="text-sm font-bold text-[#2563EB]">💡 Explanation</p>
          <p className="mt-1 text-[1rem] text-[#0F172A]">{q.explanation}</p>
          {q.translation && <div className="mt-2"><AudioPlayer text={q.translation} languageCode={mt?.tts} label="Listen" variant="ghost" /></div>}
        </div>
      )}

      {!revealed ? (
        <button onClick={confirm} disabled={selected === null} className="w-full rounded-2xl bg-[#10B981] py-4 font-display text-lg font-bold text-white disabled:opacity-50">Check Answer</button>
      ) : (
        <button onClick={next} className="flex w-full items-center justify-center gap-2 rounded-2xl bg-[#2563EB] py-4 font-display text-lg font-bold text-white">
          {current_q + 1 < questions.length ? 'Next Question' : 'See My Score'} <ArrowRight className="h-5 w-5" />
        </button>
      )}
    </div>
  );
}