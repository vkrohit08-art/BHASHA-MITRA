const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

import { useStudent } from '@/lib/StudentContext';
import { getLanguage, getSubject } from '@/lib/languages';
import AudioPlayer from '@/components/AudioPlayer';
import ProcessingState from '@/components/ProcessingState';
import { ArrowLeft, Sparkles, RotateCcw, HelpCircle, BookOpen, Trophy, Loader2, Lightbulb, Languages, MessageCircle } from 'lucide-react';

export default function LessonDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { current } = useStudent();
  const [lesson, setLesson] = useState(null);
  const [loading, setLoading] = useState(true);
  const [mtExplanation, setMtExplanation] = useState(null);
  const [translating, setTranslating] = useState(false);
  const [askOpen, setAskOpen] = useState(false);
  const [askQ, setAskQ] = useState('');
  const [askResult, setAskResult] = useState(null);
  const [asking, setAsking] = useState(false);
  const [progress, setProgress] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const l = await db.entities.Lesson.get(id);
        setLesson(l);
        // mark in-progress
        if (current) {
          const { items } = await db.entities.StudentProgress.filter(
            { student_id: current.id, lesson_id: id }, { limit: 1 }
          );
          if (items[0]) {
            setProgress(items[0]);
            if (items[0].status !== 'completed') {
              await db.entities.StudentProgress.update(items[0].id, { status: 'in_progress', last_visited: new Date().toISOString() });
            }
          } else {
            const created = await db.entities.StudentProgress.create({
              student_id: current.id, lesson_id: id, lesson_title: l.title, subject: l.subject,
              status: 'in_progress', last_visited: new Date().toISOString(),
            });
            setProgress(created);
          }
        }
      } catch (e) { /* ignore */ } finally { setLoading(false); }
    })();
  }, [id, current]);

  const translateNow = async () => {
    if (!lesson || !current) return;
    setTranslating(true);
    setMtExplanation(null);
    try {
      const res = await db.functions.invoke('aiExplain', {
        question: `Explain the lesson: ${lesson.title}. ${lesson.explanation_en}`,
        motherTongue: getLanguage(current.mother_tongue).name,
        learningLanguage: getLanguage(current.learning_language).name,
        context: `Subject: ${lesson.subject}. Concept: ${lesson.concept}.`,
        action: 'in_my_language',
        grade: current.grade,
      });
      setMtExplanation(res.data);
    } catch (e) {
      setMtExplanation({ error: e.message || 'Translation failed' });
    } finally {
      setTranslating(false);
    }
  };

  const askAI = async (action) => {
    if (!lesson || !current) return;
    setAsking(true); setAskResult(null);
    try {
      const res = await db.functions.invoke('aiExplain', {
        question: askQ || `Tell me more about ${lesson.concept}`,
        motherTongue: getLanguage(current.mother_tongue).name,
        learningLanguage: getLanguage(current.learning_language).name,
        context: `Lesson: ${lesson.title}. ${lesson.explanation_en}`,
        action,
        grade: current.grade,
      });
      setAskResult(res.data);
    } catch (e) {
      setAskResult({ error: e.message || 'AI failed' });
    } finally {
      setAsking(false);
    }
  };

  if (loading) return <div className="flex justify-center py-20"><Loader2 className="h-8 w-8 animate-spin text-[#FF7A00]" /></div>;
  if (!lesson) return <div className="py-20 text-center text-slate-500">Lesson not found.</div>;

  const subj = getSubject(lesson.subject);
  const mt = current ? getLanguage(current.mother_tongue) : null;

  return (
    <div className="space-y-5">
      <button onClick={() => navigate('/learn')} className="flex items-center gap-1 text-sm font-bold text-slate-500 hover:text-[#0F172A]">
        <ArrowLeft className="h-4 w-4" /> Back to Learn
      </button>

      <div className="rounded-[24px] border-2 border-[#E2E8F0] bg-white p-6 shadow-[0_8px_24px_-4px_rgba(37,99,235,0.12)]">
        <div className="flex items-center gap-2">
          <span className="text-3xl">{subj.icon}</span>
          <span className="rounded-full px-3 py-1 text-xs font-bold text-white" style={{ backgroundColor: subj.color }}>{lesson.subject}</span>
        </div>
        <h1 className="mt-3 font-display text-3xl font-bold text-[#0F172A]">{lesson.title}</h1>
        <p className="text-sm text-slate-500">{lesson.concept} · {lesson.difficulty}</p>
      </div>

      {/* Simple explanation */}
      <div className="rounded-[24px] border-2 border-[#E2E8F0] bg-white p-5">
        <div className="flex items-center gap-2"><BookOpen className="h-5 w-5 text-[#2563EB]" /><h2 className="font-display text-lg font-semibold text-[#0F172A]">Simple Explanation</h2></div>
        <p className="mt-2 text-[1.0625rem] leading-relaxed text-[#0F172A]">{lesson.explanation_en}</p>
        {lesson.example_en && (
          <div className="mt-3 rounded-2xl bg-[#F8FAFC] p-3 text-sm text-slate-600">
            <span className="font-bold text-[#10B981]">Example: </span>{lesson.example_en}
          </div>
        )}
        <div className="mt-4 flex flex-wrap gap-2">
          <AudioPlayer text={`${lesson.title}. ${lesson.explanation_en} ${lesson.example_en || ''}`} languageCode="en" label="Listen in English" variant="royal" />
        </div>
      </div>

      {/* Mother-tongue explanation */}
      <div className="rounded-[24px] border-2 border-[#FF7A00]/30 bg-[#FF7A00]/5 p-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2"><Languages className="h-5 w-5 text-[#FF7A00]" /><h2 className="font-display text-lg font-semibold text-[#0F172A]">In Your Language ({mt?.native})</h2></div>
          <button onClick={translateNow} disabled={translating}
            className="rounded-full bg-[#FF7A00] px-4 py-2 text-sm font-bold text-white disabled:opacity-50">
            {translating ? 'Translating…' : mtExplanation ? 'Explain Again' : 'Translate'}
          </button>
        </div>
        {translating && <div className="mt-4"><ProcessingState stage="translating" hint={`Explaining in ${mt?.name}…`} /></div>}
        {mtExplanation && !mtExplanation.error && (
          <div className="mt-3">
            <p className="text-[1.0625rem] leading-relaxed text-[#0F172A]">{mtExplanation.translation}</p>
            <div className="mt-3"><AudioPlayer text={mtExplanation.translation} languageCode={mt?.tts} label={`Listen in ${mt?.name}`} variant="saffron" /></div>
          </div>
        )}
        {mtExplanation?.error && <p className="mt-3 text-sm font-semibold text-[#FF7A00]">{mtExplanation.error}</p>}
      </div>

      {/* AI Tutor */}
      <div className="rounded-[24px] border-2 border-[#8B5CF6]/30 bg-[#8B5CF6]/5 p-5">
        <div className="flex items-center gap-2"><Sparkles className="h-5 w-5 text-[#8B5CF6]" /><h2 className="font-display text-lg font-semibold text-[#0F172A]">Ask AI Tutor</h2></div>
        <p className="mt-1 text-sm text-slate-500">Ask a question or pick a quick action.</p>

        <div className="mt-3 flex flex-wrap gap-2">
          <input value={askQ} onChange={(e) => setAskQ(e.target.value)} placeholder="Type your question…"
            className="min-w-[200px] flex-1 rounded-2xl border-2 border-[#E2E8F0] px-4 py-2.5 text-base outline-none focus:border-[#8B5CF6]" />
          <button onClick={() => askAI('explain')} disabled={asking}
            className="rounded-2xl bg-[#8B5CF6] px-4 py-2.5 text-sm font-bold text-white disabled:opacity-50">Ask</button>
        </div>

        <div className="mt-3 grid grid-cols-2 gap-2 lg:grid-cols-4">
          {[
            { label: 'Explain Simply', action: 'explain', icon: Lightbulb },
            { label: 'Give Example', action: 'example', icon: Sparkles },
            { label: 'In My Language', action: 'in_my_language', icon: Languages },
            { label: 'Ask Me a Question', action: 'ask_question', icon: MessageCircle },
          ].map((b) => (
            <button key={b.action} onClick={() => askAI(b.action)} disabled={asking}
              className="flex flex-col items-center gap-1 rounded-2xl border-2 border-[#E2E8F0] bg-white p-3 text-xs font-bold text-[#8B5CF6] disabled:opacity-50">
              <b.icon className="h-5 w-5" /> {b.label}
            </button>
          ))}
        </div>

        {asking && <div className="mt-4"><ProcessingState stage="explaining" hint="The AI tutor is thinking…" /></div>}
        {askResult && !askResult.error && (
          <div className="mt-4 space-y-3 rounded-2xl bg-white p-4">
            <p className="text-[1.0625rem] leading-relaxed text-[#0F172A]">{askResult.explanation}</p>
            {askResult.translation && (
              <div className="rounded-xl bg-[#FF7A00]/5 p-3">
                <p className="text-sm font-semibold text-[#FF7A00]">{mt?.native}:</p>
                <p className="mt-1 text-[1rem] leading-relaxed text-[#0F172A]">{askResult.translation}</p>
                <div className="mt-2"><AudioPlayer text={askResult.translation} languageCode={mt?.tts} label="Listen" variant="saffron" /></div>
              </div>
            )}
            {askResult.encouragement && <p className="text-sm font-semibold text-[#10B981]">🌟 {askResult.encouragement}</p>}
            {askResult.followUpQuestion && <p className="rounded-xl bg-[#8B5CF6]/10 p-3 text-sm font-semibold text-[#8B5CF6]">💬 {askResult.followUpQuestion}</p>}
          </div>
        )}
        {askResult?.error && <p className="mt-3 text-sm font-semibold text-[#FF7A00]">{askResult.error}</p>}
      </div>

      {/* Quiz CTA */}
      <button onClick={() => navigate(`/quiz/${lesson.id}`)}
        className="flex w-full items-center justify-between rounded-[24px] bg-[#10B981] p-5 text-white shadow-[0_8px_24px_-4px_rgba(16,185,129,0.4)]">
        <span className="flex items-center gap-3"><Trophy className="h-7 w-7" /><span className="font-display text-xl font-bold">Test My Understanding</span></span>
        <ArrowLeft className="h-6 w-6 rotate-180" />
      </button>
    </div>
  );
}