const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';

import { useStudent } from '@/lib/StudentContext';
import { getLanguage } from '@/lib/languages';
import { recordAudio, uploadAudio } from '@/lib/audio';
import AudioPlayer from '@/components/AudioPlayer';
import ProcessingState from '@/components/ProcessingState';
import { Mic, Square, Send, Loader2, RotateCcw, Volume2, AlertTriangle, MessageCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function TalkLearn() {
  const navigate = useNavigate();
  const { current } = useStudent();
  const [recording, setRecording] = useState(false);
  const [stage, setStage] = useState(null); // listening | understanding | translating
  const [transcript, setTranscript] = useState('');
  const [typed, setTyped] = useState('');
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [history, setHistory] = useState([]);
  const timerRef = useRef(null);

  if (!current) {
    return <div className="py-20 text-center"><button onClick={() => navigate('/onboarding')} className="rounded-2xl bg-[#FF7A00] px-6 py-3 font-bold text-white">Set up a learner</button></div>;
  }
  const mt = getLanguage(current.mother_tongue);
  const ll = getLanguage(current.learning_language);

  const handleExplain = async (question) => {
    if (!question.trim()) { setError('Please ask a question first.'); return; }
    setError(''); setResult(null);
    db.analytics.track('talk_and_learn_started', { grade: current.grade, mother_tongue: current.mother_tongue });
    setStage('understanding');
    try {
      const res = await db.functions.invoke('aiExplain', {
        question,
        motherTongue: mt.name,
        learningLanguage: ll.name,
        action: 'explain',
        grade: current.grade,
      });
      setResult(res.data);
      setStage('translating');
      // save history
      try {
        await db.entities.ConversationHistory.create({
          student_id: current.id, type: 'talk',
          question, answer: res.data.explanation, translation: res.data.translation, language: mt.code,
        });
      } catch (e) { /* ignore */ }
      setHistory((h) => [{ question, ...res.data }, ...h].slice(0, 10));
    } catch (e) {
      setError(e.message || 'Could not understand. Please try again.');
    } finally {
      setStage(null);
    }
  };

  const startRecording = async () => {
    setError(''); setResult(null); setTranscript('');
    setRecording(true); setStage('listening');
    try {
      const blob = await recordAudio(7000);
      setStage('understanding');
      const audioUrl = await uploadAudio(blob);
      const tr = await db.functions.invoke('transcribeAudio', { audioUrl });
      const text = (tr.data?.transcript || '').trim();
      if (!text) { setError('I could not hear you clearly. Please try again, or type your question.'); setStage(null); return; }
      setTranscript(text);
      await handleExplain(text);
    } catch (e) {
      const msg = e?.name === 'NotAllowedError' ? 'Microphone permission denied. Please allow microphone access.' : (e.message || 'Recording failed.');
      setError(msg); setStage(null);
    } finally {
      setRecording(false);
    }
  };

  const submitTyped = () => {
    if (!typed.trim()) return;
    setTranscript(typed);
    handleExplain(typed);
    setTyped('');
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-display text-3xl font-bold text-[#0F172A]">Talk & Learn 🎙️</h1>
        <p className="text-slate-500">Ask anything in your voice. I'll explain in {mt.native} and read it aloud.</p>
      </div>

      {/* Mic stage */}
      <div className="flex flex-col items-center rounded-[24px] border-2 border-[#E2E8F0] bg-white p-8">
        <button
          onClick={recording ? undefined : startRecording}
          disabled={!!stage}
          className={cn(
            'relative flex h-20 w-20 items-center justify-center rounded-full text-white transition disabled:opacity-60',
            recording ? 'bg-[#FF7A00]' : 'bg-[#FF7A00] shadow-[0_8px_24px_-4px_rgba(255,122,0,0.5)]'
          )}
        >
          {recording ? (
            <>
              <Square className="h-8 w-8 fill-current" />
              <span className="absolute inset-0 animate-ping rounded-full bg-[#FF7A00]/40" />
            </>
          ) : stage ? (
            <Loader2 className="h-8 w-8 animate-spin" />
          ) : (
            <Mic className="h-9 w-9" />
          )}
        </button>
        <p className="mt-4 font-display text-lg font-semibold text-[#0F172A]">
          {recording ? 'Listening… speak now' : stage ? 'Processing…' : 'Tap to speak'}
        </p>
        <p className="text-sm text-slate-500">e.g. "Why does the moon change its shape?"</p>
      </div>

      {stage && <ProcessingState stage={stage} hint={stage === 'listening' ? 'Capture your voice' : stage === 'understanding' ? 'Turning speech into text and thinking…' : 'Translating into your language…'} />}

      {error && (
        <div className="flex items-start gap-2 rounded-2xl bg-[#FF7A00]/10 p-4 text-sm font-semibold text-[#FF7A00]">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" /> {error}
        </div>
      )}

      {/* Typed fallback */}
      <div className="rounded-[24px] border-2 border-[#E2E8F0] bg-white p-4">
        <p className="mb-2 text-sm font-bold text-slate-600">Or type your question</p>
        <div className="flex gap-2">
          <input value={typed} onChange={(e) => setTyped(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && submitTyped()}
            placeholder="Type a question…" className="flex-1 rounded-2xl border-2 border-[#E2E8F0] px-4 py-3 text-base outline-none focus:border-[#FF7A00]" />
          <button onClick={submitTyped} disabled={!!stage} className="flex items-center gap-1 rounded-2xl bg-[#2563EB] px-4 py-3 font-bold text-white disabled:opacity-50"><Send className="h-4 w-4" /> Ask</button>
        </div>
      </div>

      {/* Result */}
      {result && !result.error && (
        <div className="space-y-4 rounded-[24px] border-2 border-[#E2E8F0] bg-white p-5">
          {transcript && (
            <div className="rounded-2xl bg-[#F8FAFC] p-4">
              <p className="text-xs font-bold text-slate-400">YOUR QUESTION</p>
              <p className="mt-1 text-[1.0625rem] font-medium text-[#0F172A]">"{transcript}"</p>
              {result.detectedLanguage && <p className="mt-1 text-xs font-semibold text-[#2563EB]">Detected: {result.detectedLanguage}</p>}
            </div>
          )}
          <div>
            <p className="text-xs font-bold text-[#2563EB]">AI ANSWER (ENGLISH)</p>
            <p className="mt-1 text-[1.0625rem] leading-relaxed text-[#0F172A]">{result.explanation}</p>
            <div className="mt-2"><AudioPlayer text={result.explanation} languageCode="en" label="Listen" variant="royal" /></div>
          </div>
          <div className="rounded-2xl bg-[#FF7A00]/5 p-4">
            <p className="text-xs font-bold text-[#FF7A00]">TRANSLATION ({mt.native})</p>
            <p className="mt-1 text-[1.0625rem] leading-relaxed text-[#0F172A]">{result.translation}</p>
            <div className="mt-2"><AudioPlayer text={result.translation} languageCode={mt.tts} label={`Listen in ${mt.name}`} variant="saffron" /></div>
          </div>
          {result.encouragement && <p className="text-sm font-semibold text-[#10B981]">🌟 {result.encouragement}</p>}
          {result.followUpQuestion && (
            <div className="flex items-start gap-2 rounded-2xl bg-[#8B5CF6]/10 p-3">
              <MessageCircle className="mt-0.5 h-4 w-4 shrink-0 text-[#8B5CF6]" />
              <p className="text-sm font-semibold text-[#8B5CF6]">{result.followUpQuestion}</p>
            </div>
          )}
          <button onClick={() => { setResult(null); setTranscript(''); }} className="flex items-center gap-1 text-sm font-bold text-slate-500 hover:text-[#0F172A]"><RotateCcw className="h-4 w-4" /> Ask another</button>
        </div>
      )}

      {history.length > 0 && (
        <div>
          <h2 className="mb-2 font-display text-lg font-semibold text-[#0F172A]">Recent questions</h2>
          <div className="space-y-2">
            {history.map((h, i) => (
              <div key={i} className="rounded-2xl border-2 border-[#E2E8F0] bg-white p-3">
                <p className="text-sm font-semibold text-[#0F172A]">"{h.question}"</p>
                <p className="mt-1 text-sm text-slate-500">{h.explanation?.slice(0, 90)}…</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}