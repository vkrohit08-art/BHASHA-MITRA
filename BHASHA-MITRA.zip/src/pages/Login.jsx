const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from "react";
import { Link } from "react-router-dom";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Mail, Lock, Loader2, Eye, EyeOff, GraduationCap, BookOpen, Heart } from "lucide-react";
import AuthLayout from "@/components/AuthLayout";
import GoogleIcon from "@/components/GoogleIcon";
import { safeReturnTo } from "@/lib/authReturnTo";

const ROLES = [
  { id: "student", label: "Student", icon: GraduationCap, hint: "Continue your learning journey" },
  { id: "teacher", label: "Teacher", icon: BookOpen, hint: "Manage your classroom" },
  { id: "parent", label: "Parent", icon: Heart, hint: "Follow your child's progress" },
];

export default function Login() {
  const [role, setRole] = useState(() => localStorage.getItem("bm_login_role") || "student");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const returnTo = safeReturnTo();

  const activeRole = ROLES.find((r) => r.id === role) || ROLES[0];

  const chooseRole = (id) => {
    setRole(id);
    localStorage.setItem("bm_login_role", id);
  };

  const destAfterLogin = () => {
    if (returnTo !== "/") return returnTo;
    if (role === "teacher") return "/teacher";
    if (role === "parent") return "/parent";
    return "/";
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await db.auth.loginViaEmailPassword(email, password);
      window.location.href = destAfterLogin();
    } catch (err) {
      setError(err.message || "Invalid email or password");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogle = () => {
    db.auth.loginWithProvider("google", destAfterLogin());
  };

  return (
    <AuthLayout
      title="Welcome back"
      subtitle={activeRole.hint}
      footer={
        <>
          New to BHASHA-MITRA?{" "}
          <Link
            to={"/register" + (returnTo !== "/" ? "?returnTo=" + encodeURIComponent(returnTo) : "")}
            className="text-primary font-semibold hover:underline"
          >
            Create an account
          </Link>
        </>
      }
    >
      <div className="grid grid-cols-3 gap-2 mb-6">
        {ROLES.map((r) => {
          const Icon = r.icon;
          const active = r.id === role;
          return (
            <button
              type="button"
              key={r.id}
              onClick={() => chooseRole(r.id)}
              className={
                "flex flex-col items-center gap-1.5 rounded-2xl border px-2 py-3 text-xs font-medium transition " +
                (active
                  ? "border-orange-500 bg-orange-50 text-orange-700 shadow-sm"
                  : "border-border bg-background text-muted-foreground hover:bg-muted/50")
              }
            >
              <Icon className={"w-5 h-5 " + (active ? "text-orange-600" : "text-muted-foreground")} />
              {r.label}
            </button>
          );
        })}
      </div>

      <Button variant="outline" className="w-full h-11 text-sm font-medium mb-4 bg-background" onClick={handleGoogle}>
        <GoogleIcon className="w-4 h-4 mr-2" />
        Continue with Google
      </Button>

      <div className="relative mb-5">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-border" />
        </div>
        <div className="relative flex justify-center text-[11px] uppercase tracking-wide">
          <span className="bg-card px-3 text-muted-foreground">or sign in with email</span>
        </div>
      </div>

      {error && (
        <div className="mb-4 p-3 rounded-xl bg-destructive/10 text-destructive text-sm">{error}</div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="email" className="text-sm">Email</Label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
            <Input
              id="email"
              type="email"
              autoComplete="email"
              autoFocus
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="pl-10 h-11"
              required
            />
          </div>
        </div>
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <Label htmlFor="password" className="text-sm">Password</Label>
            <Link to="/forgot-password" className="text-xs text-primary hover:underline">Forgot?</Link>
          </div>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
            <Input
              id="password"
              type={showPw ? "text" : "password"}
              autoComplete="current-password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="pl-10 pr-10 h-11"
              required
            />
            <button
              type="button"
              onClick={() => setShowPw((s) => !s)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              aria-label={showPw ? "Hide password" : "Show password"}
            >
              {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>
        <Button type="submit" className="w-full h-11 font-semibold" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Signing in...
            </>
          ) : (
            "Sign in"
          )}
        </Button>
      </form>
    </AuthLayout>
  );
}