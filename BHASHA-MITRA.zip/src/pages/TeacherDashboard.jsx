const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';

import { SUBJECTS, getSubject, LANGUAGES } from '@/lib/languages';
import { Users, Award, AlertTriangle, BookOpen, Trophy, Loader2, GraduationCap } from 'lucide-react';

export default function TeacherDashboard() {
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    studentCount: 0, totalAttempts: 0, avgScore: 0, completed: 0, inProgress: 0,
    bySubject: [], langDist: [], attention: [],
  });

  useEffect(() => {
    (async () => {
      try {
        const [studentCount, subjectAgg, progressAgg, langAgg] = await Promise.all([
          db.entities.StudentProfile.count({ role: 'student' }),
          db.entities.QuizAttempt.aggregate({ groupBy: 'subject', avg: 'score', count: true, sum: 'total', sort: '-count' }),
          db.entities.StudentProgress.aggregate({ groupBy: 'status', count: true }),
          db.entities.StudentProfile.aggregate({ groupBy: 'mother_tongue', count: true }),
        ]);

        const rows = subjectAgg?.rows || [];
        const totalAttempts = rows.reduce((s, r) => s + (r.count || 0), 0);
        const totalScore = rows.reduce((s, r) => s + (r.avg_score || 0) * (r.count || 0), 0);
        const avgScore = totalAttempts ? Math.round((totalScore / totalAttempts) * 10) / 10 : 0;

        const bySubject = rows.map((r) => ({ subject: r.subject, count: r.count, avg: Math.round((r.avg_score || 0) * 10) / 10 })).sort((a, b) => a.avg - b.avg);

        const completed = (progressAgg?.rows || []).find((r) => r.status === 'completed')?.count || 0;
        const inProgress = (progressAgg?.rows || []).find((r) => r.status === 'in_progress')?.count || 0;

        const langDist = (langAgg?.rows || []).map((r) => ({
          lang: LANGUAGES.find((l) => l.code === r.mother_tongue)?.name || r.mother_tongue,
          native: LANGUAGES.find((l) => l.code === r.mother_tongue)?.native || r.mother_tongue,
          count: r.count,
        }));

        // students needing attention: recent low attempts
        let attention = [];
        try {
          const { items } = await db.entities.QuizAttempt.filter({}, { sort: '-created_date', limit: 50, fields: ['student_name', 'lesson_title', 'subject', 'score', 'total', 'created_date'] });
          attention = items.filter((a) => a.total > 0 && (a.score / a.total) < 0.5).slice(0, 6);
        } catch (e) { /* ignore */ }

        setStats({ studentCount: studentCount || 0, totalAttempts, avgScore, completed, inProgress, bySubject, langDist, attention });
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) return <div className="flex justify-center py-20"><Loader2 className="h-8 w-8 animate-spin text-[#FF7A00]" /></div>;

  const cards = [
    { label: 'Students', value: stats.studentCount, icon: Users, color: '#2563EB' },
    { label: 'Quiz Attempts', value: stats.totalAttempts, icon: Trophy, color: '#FF7A00' },
    { label: 'Avg Score', value: `${stats.avgScore}`, icon: Award, color: '#10B981' },
    { label: 'Lessons Completed', value: stats.completed, icon: BookOpen, color: '#8B5CF6' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <GraduationCap className="h-7 w-7 text-[#10B981]" />
        <div>
          <h1 className="font-display text-3xl font-bold text-[#0F172A]">Teacher Dashboard</h1>
          <p className="text-slate-500">Class performance and insights</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {cards.map((c) => (
          <div key={c.label} className="rounded-[24px] border-2 border-[#E2E8F0] bg-white p-4" style={{ boxShadow: `0 8px 24px -4px ${c.color}22` }}>
            <span className="flex h-10 w-10 items-center justify-center rounded-2xl text-white" style={{ backgroundColor: c.color }}><c.icon className="h-5 w-5" /></span>
            <p className="mt-3 font-display text-3xl font-bold text-[#0F172A]">{c.value}</p>
            <p className="text-sm font-semibold text-slate-500">{c.label}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Most difficult concepts */}
        <div className="rounded-[24px] border-2 border-[#E2E8F0] bg-white p-5">
          <h2 className="font-display text-lg font-semibold text-[#0F172A]">Most Difficult Concepts</h2>
          <p className="text-sm text-slate-500">Lowest average quiz score by subject</p>
          <div className="mt-4 space-y-3">
            {stats.bySubject.length === 0 && <p className="text-sm text-slate-400">No quiz data yet.</p>}
            {stats.bySubject.map((s) => {
              const subj = getSubject(s.subject);
              const pct = s.totalAttempts ? Math.round((s.avg / 5) * 100) : Math.round((s.avg / 5) * 100);
              return (
                <div key={s.subject}>
                  <div className="flex items-center justify-between text-sm font-semibold">
                    <span>{subj.icon} {s.subject}</span>
                    <span className="text-slate-500">{s.avg} avg · {s.count} attempts</span>
                  </div>
                  <div className="mt-1 h-2 overflow-hidden rounded-full bg-[#E2E8F0]">
                    <div className="h-full rounded-full" style={{ width: `${Math.min(100, (s.avg / 5) * 100)}%`, backgroundColor: subj.color }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Language distribution */}
        <div className="rounded-[24px] border-2 border-[#E2E8F0] bg-white p-5">
          <h2 className="font-display text-lg font-semibold text-[#0F172A]">Language Distribution</h2>
          <p className="text-sm text-slate-500">Mother tongues in your class</p>
          <div className="mt-4 space-y-2">
            {stats.langDist.length === 0 && <p className="text-sm text-slate-400">No students yet.</p>}
            {stats.langDist.map((l) => (
              <div key={l.lang} className="flex items-center justify-between rounded-2xl bg-[#F8FAFC] px-4 py-2">
                <span className="font-semibold text-[#0F172A]">{l.native} · {l.lang}</span>
                <span className="rounded-full bg-[#FF7A00]/10 px-3 py-1 text-sm font-bold text-[#FF7A00]">{l.count}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Students needing attention */}
      <div className="rounded-[24px] border-2 border-[#FF7A00]/30 bg-[#FF7A00]/5 p-5">
        <div className="flex items-center gap-2"><AlertTriangle className="h-5 w-5 text-[#FF7A00]" /><h2 className="font-display text-lg font-semibold text-[#0F172A]">Students Needing Attention</h2></div>
        <p className="text-sm text-slate-500">Recent quiz scores below 50%</p>
        <div className="mt-3 space-y-2">
          {stats.attention.length === 0 && <p className="text-sm text-[#10B981] font-semibold">🎉 No one needs help right now. Great class!</p>}
          {stats.attention.map((a, i) => (
            <div key={i} className="flex items-center justify-between rounded-2xl bg-white p-3">
              <span><span className="font-bold text-[#0F172A]">{a.student_name}</span> <span className="text-sm text-slate-500">· {a.lesson_title}</span></span>
              <span className="rounded-full bg-[#FF7A00]/10 px-3 py-1 text-sm font-bold text-[#FF7A00]">{a.score}/{a.total}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}