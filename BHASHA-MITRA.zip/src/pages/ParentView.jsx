const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { useStudent } from '@/lib/StudentContext';
import { getLanguage, SUBJECTS, getSubject } from '@/lib/languages';
import { Clock, BookOpen, Trophy, Sparkles, Loader2, User, ArrowRight } from 'lucide-react';

export default function ParentView() {
  const navigate = useNavigate();
  const { current, loading } = useStudent();
  const [data, setData] = useState(null);

  useEffect(() => {
    if (!current) return;
    (async () => {
      try {
        const [progressAgg, quizAgg, attempts, completed] = await Promise.all([
          db.entities.StudentProgress.aggregate({ query: { student_id: current.id }, sum: 'time_spent_sec', groupBy: 'status' }),
          db.entities.QuizAttempt.aggregate({ query: { student_id: current.id }, groupBy: 'subject', avg: 'score', count: true, sum: 'total' }),
          db.entities.QuizAttempt.count({ student_id: current.id }),
          db.entities.StudentProgress.count({ student_id: current.id, status: 'completed' }),
        ]);

        const timeSpent = (progressAgg?.rows || []).reduce((s, r) => s + (r.sum_time_spent_sec || 0), 0);
        const rows = (quizAgg?.rows || []).map((r) => ({
          subject: r.subject, count: r.count, avg: Math.round((r.avg_score || 0) * 10) / 10,
        })).sort((a, b) => a.avg - b.avg);
        const totalScore = rows.reduce((s, r) => s + r.avg * r.count, 0);
        const totalCount = rows.reduce((s, r) => s + r.count, 0);
        const overallAvg = totalCount ? Math.round((totalScore / totalCount) * 10) / 10 : 0;

        setData({ timeSpent, attempts: attempts || 0, completed: completed || 0, overallAvg, rows });
      } catch (e) { console.error(e); }
    })();
  }, [current]);

  if (loading || !current) return <div className="flex justify-center py-20"><Loader2 className="h-8 w-8 animate-spin text-[#FF7A00]" /></div>;
  const mt = getLanguage(current.mother_tongue);

  const cards = [
    { label: 'Learning Time', value: `${Math.round((data?.timeSpent || 0) / 60)} min`, icon: Clock, color: '#2563EB' },
    { label: 'Lessons Done', value: data?.completed || 0, icon: BookOpen, color: '#10B981' },
    { label: 'Quizzes Taken', value: data?.attempts || 0, icon: Trophy, color: '#FF7A00' },
    { label: 'Avg Score', value: data?.overallAvg || 0, icon: Sparkles, color: '#8B5CF6' },
  ];

  const weakest = data?.rows?.[0];

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <User className="h-7 w-7 text-[#8B5CF6]" />
        <div>
          <h1 className="font-display text-3xl font-bold text-[#0F172A]">Parent View</h1>
          <p className="text-slate-500">{current.name}'s learning summary</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {cards.map((c) => (
          <div key={c.label} className="rounded-[24px] border-2 border-[#E2E8F0] bg-white p-4" style={{ boxShadow: `0 8px 24px -4px ${c.color}22` }}>
            <span className="flex h-10 w-10 items-center justify-center rounded-2xl text-white" style={{ backgroundColor: c.color }}><c.icon className="h-5 w-5" /></span>
            <p className="mt-3 font-display text-2xl font-bold text-[#0F172A]">{c.value}</p>
            <p className="text-sm font-semibold text-slate-500">{c.label}</p>
          </div>
        ))}
      </div>

      {weakest && (
        <div className="rounded-[24px] border-2 border-dashed border-[#8B5CF6] bg-[#8B5CF6]/5 p-5">
          <div className="flex items-center gap-2"><Sparkles className="h-5 w-5 text-[#8B5CF6]" /><h2 className="font-display text-lg font-semibold text-[#8B5CF6]">Improvement Area</h2></div>
          <p className="mt-1 text-sm text-slate-500">{current.name} can grow stronger in {weakest.subject} (avg {weakest.avg}).</p>
          <p className="mt-2 text-sm font-semibold text-[#0F172A]">Recommended activity: Practice {weakest.subject} together for 10 minutes daily, using examples from home.</p>
        </div>
      )}

      <div className="rounded-[24px] border-2 border-[#E2E8F0] bg-white p-5">
        <h2 className="font-display text-lg font-semibold text-[#0F172A]">Subject Performance</h2>
        <div className="mt-3 space-y-3">
          {(data?.rows || []).map((r) => {
            const subj = getSubject(r.subject);
            return (
              <div key={r.subject}>
                <div className="flex items-center justify-between text-sm font-semibold">
                  <span>{subj.icon} {r.subject}</span>
                  <span className="text-slate-500">{r.avg} avg · {r.count} quizzes</span>
                </div>
                <div className="mt-1 h-2 overflow-hidden rounded-full bg-[#E2E8F0]">
                  <div className="h-full rounded-full" style={{ width: `${Math.min(100, (r.avg / 5) * 100)}%`, backgroundColor: subj.color }} />
                </div>
              </div>
            );
          })}
          {(!data?.rows || data.rows.length === 0) && <p className="text-sm text-slate-400">No quiz activity yet. Encourage {current.name} to try a quiz!</p>}
        </div>
      </div>

      <button onClick={() => navigate('/')} className="flex w-full items-center justify-center gap-2 rounded-2xl bg-[#8B5CF6] py-3 font-bold text-white">Back to Home <ArrowRight className="h-4 w-4" /></button>
    </div>
  );
}