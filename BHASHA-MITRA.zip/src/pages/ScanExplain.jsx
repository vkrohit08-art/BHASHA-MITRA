const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { useStudent } from '@/lib/StudentContext';
import { getLanguage } from '@/lib/languages';
import { uploadImage } from '@/lib/audio';
import AudioPlayer from '@/components/AudioPlayer';
import ProcessingState from '@/components/ProcessingState';
import CameraCapture from '@/components/CameraCapture';
import { Camera, Upload, Loader2, AlertTriangle, Trophy, ScanLine } from 'lucide-react';

export default function ScanExplain() {
  const navigate = useNavigate();
  const { current } = useStudent();
  const fileRef = useRef(null);
  const [stage, setStage] = useState(null);
  const [showCam, setShowCam] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [preview, setPreview] = useState(null);

  const mt = current ? getLanguage(current.mother_tongue) : null;

  const handleFile = async (file) => {
    if (!file) return;
    setError(''); setResult(null); setPreview(URL.createObjectURL(file));
    setStage('scanning');
    try {
      const { signed_url } = await uploadImage(file);
      setStage('reading');
      const res = await db.functions.invoke('ocrExplain', {
        imageUrl: signed_url,
        motherTongue: mt?.name || 'Kannada',
        learningLanguage: getLanguage(current?.learning_language || 'en').name,
        grade: current?.grade || 'Class 3',
      });
      if (res.data?.error) { setError(res.data.error); setResult(null); }
      else setResult(res.data);
    } catch (e) {
      setError(e.message || 'Could not read this image. Try a clearer photo.');
    } finally {
      setStage(null);
    }
  };

  const onCamera = (e) => { const f = e.target.files?.[0]; if (f) handleFile(f); e.target.value = ''; };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-display text-3xl font-bold text-[#0F172A]">Scan & Explain 📸</h1>
        <p className="text-slate-500">Photograph a textbook page — get a simple explanation in your language.</p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <button onClick={() => setShowCam(true)} className="flex flex-col items-center gap-2 rounded-[24px] border-2 border-[#E2E8F0] bg-white p-6 font-display font-semibold text-[#FF7A00] hover:border-[#FF7A00]">
          <Camera className="h-8 w-8" /> Take Photo
        </button>
        <button onClick={() => fileRef.current?.click()} className="flex flex-col items-center gap-2 rounded-[24px] border-2 border-[#E2E8F0] bg-white p-6 font-display font-semibold text-[#2563EB] hover:border-[#2563EB]">
          <Upload className="h-8 w-8" /> Upload Image
        </button>
        <input ref={fileRef} type="file" accept="image/*" onChange={onCamera} className="hidden" />
      </div>

      <p className="text-center text-xs text-slate-400">Tip: good lighting and a flat, steady page give the best results.</p>

      {showCam && (
        <CameraCapture
          onCapture={(file) => { setShowCam(false); handleFile(file); }}
          onClose={() => setShowCam(false)}
        />
      )}

      {preview && (
        <div className="overflow-hidden rounded-[24px] border-2 border-[#E2E8F0]">
          <img src={preview} alt="scan preview" className="max-h-64 w-full object-cover" />
        </div>
      )}

      {stage && <ProcessingState stage={stage} hint={stage === 'scanning' ? 'Reading text from the image…' : 'Simplifying and translating…'} />}

      {error && (
        <div className="flex items-start gap-2 rounded-2xl bg-[#FF7A00]/10 p-4 text-sm font-semibold text-[#FF7A00]">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" /> {error}
        </div>
      )}

      {result && (
        <div className="space-y-4">
          {result.extractedText && (
            <div className="rounded-[24px] border-2 border-[#E2E8F0] bg-[#F8FAFC] p-4">
              <p className="flex items-center gap-1 text-xs font-bold text-slate-400"><ScanLine className="h-4 w-4" /> TEXT READ FROM IMAGE</p>
              <p className="mt-1 whitespace-pre-wrap text-sm text-slate-600">{result.extractedText.slice(0, 500)}</p>
            </div>
          )}
          <div className="rounded-[24px] border-2 border-[#E2E8F0] bg-white p-5">
            <div className="flex items-center gap-2"><ScanLine className="h-5 w-5 text-[#2563EB]" /><h2 className="font-display text-lg font-semibold text-[#0F172A]">Simple Explanation</h2></div>
            {result.concept && <span className="mt-1 inline-block rounded-full bg-[#2563EB]/10 px-3 py-1 text-xs font-bold text-[#2563EB]">{result.concept}</span>}
            <p className="mt-3 text-[1.0625rem] leading-relaxed text-[#0F172A]">{result.explanation}</p>
            <div className="mt-3"><AudioPlayer text={result.explanation} languageCode="en" label="Listen in English" variant="royal" /></div>
          </div>
          <div className="rounded-[24px] border-2 border-[#FF7A00]/30 bg-[#FF7A00]/5 p-5">
            <h2 className="font-display text-lg font-semibold text-[#0F172A]">Mother-Tongue Explanation ({mt?.native})</h2>
            <p className="mt-2 text-[1.0625rem] leading-relaxed text-[#0F172A]">{result.translation}</p>
            <div className="mt-3"><AudioPlayer text={result.translation} languageCode={mt?.tts} label={`Listen in ${mt?.name}`} variant="saffron" /></div>
          </div>
          <button onClick={() => navigate('/quiz')} className="flex w-full items-center justify-center gap-2 rounded-2xl bg-[#10B981] py-4 font-display text-lg font-bold text-white">
            <Trophy className="h-5 w-5" /> Test My Understanding
          </button>
        </div>
      )}
    </div>
  );
}