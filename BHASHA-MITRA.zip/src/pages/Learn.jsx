const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';

import { useStudent } from '@/lib/StudentContext';
import { SUBJECTS } from '@/lib/languages';
import { cn } from '@/lib/utils';
import { ArrowRight, Loader2 } from 'lucide-react';

export default function Learn() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { current } = useStudent();
  const [subject, setSubject] = useState(searchParams.get('subject') || 'Science');
  const [lessons, setLessons] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const { items } = await db.entities.Lesson.filter(
          { subject },
          { sort: 'order', limit: 50, fields: ['title', 'concept', 'subject', 'difficulty', 'grade'] }
        );
        setLessons(items);
      } catch (e) {
        setLessons([]);
      } finally {
        setLoading(false);
      }
    })();
  }, [subject]);

  const pick = (s) => {
    setSubject(s);
    setSearchParams({ subject: s });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-bold text-[#0F172A]">Learn</h1>
        <p className="text-slate-500">Choose a subject and start a lesson.</p>
      </div>

      {/* Subject ribbon */}
      <div className="flex gap-3 overflow-x-auto pb-1 lg:grid lg:grid-cols-5 lg:overflow-visible">
        {SUBJECTS.map((s) => (
          <button key={s.key} onClick={() => pick(s.key)}
            className={cn(
              'flex min-w-[130px] flex-col items-center gap-2 rounded-[24px] border-2 p-4 lg:min-w-0',
              subject === s.key ? 'border-transparent text-white' : 'border-[#E2E8F0] bg-white text-[#0F172A]'
            )}
            style={subject === s.key ? { backgroundColor: s.color } : {}}>
            <span className="text-3xl">{s.icon}</span>
            <span className="font-display text-sm font-semibold">{s.key}</span>
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex justify-center py-16"><Loader2 className="h-7 w-7 animate-spin text-[#FF7A00]" /></div>
      ) : lessons.length === 0 ? (
        <div className="rounded-3xl border-2 border-dashed border-[#E2E8F0] bg-[#F8FAFC] p-10 text-center text-slate-500">
          No lessons yet for {subject}. Ask your teacher to add one!
        </div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {lessons.map((l) => {
            const subj = SUBJECTS.find((s) => s.key === l.subject);
            return (
              <button key={l.id} onClick={() => navigate(`/lesson/${l.id}`)}
                className="group flex items-center gap-4 rounded-[24px] border-2 border-[#E2E8F0] bg-white p-4 text-left transition hover:-translate-y-0.5"
                style={{ boxShadow: `0 8px 24px -4px ${subj?.color}22` }}>
                <span className="flex h-12 w-12 items-center justify-center rounded-2xl text-2xl" style={{ backgroundColor: `${subj?.color}15` }}>
                  {subj?.icon}
                </span>
                <span className="flex-1">
                  <span className="block font-display text-base font-semibold text-[#0F172A]">{l.title}</span>
                  <span className="block text-sm text-slate-500">{l.concept} · {l.difficulty}</span>
                </span>
                <ArrowRight className="h-5 w-5 text-slate-300 group-hover:text-[#FF7A00]" />
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}