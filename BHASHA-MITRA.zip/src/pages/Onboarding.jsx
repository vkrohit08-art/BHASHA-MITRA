const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

import { LANGUAGES, SUBJECTS } from '@/lib/languages';
import { useStudent } from '@/lib/StudentContext';
import { Loader2, Check } from 'lucide-react';
import { cn } from '@/lib/utils';

const COLORS = ['#FF7A00', '#2563EB', '#10B981', '#8B5CF6', '#0F172A'];

export default function Onboarding() {
  const navigate = useNavigate();
  const { profiles, current, selectStudent, loading } = useStudent();
  const [name, setName] = useState('');
  const [grade, setGrade] = useState('Class 3');
  const [motherTongue, setMotherTongue] = useState('kn');
  const [learningLanguage, setLearningLanguage] = useState('en');
  const [interfaceLanguage, setInterfaceLanguage] = useState('en');
  const [color, setColor] = useState(COLORS[0]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const create = async () => {
    if (!name.trim()) { setError('Please enter a name'); return; }
    setSaving(true); setError('');
    try {
      const created = await db.entities.StudentProfile.create({
        name: name.trim(),
        grade,
        role: 'student',
        mother_tongue: motherTongue,
        learning_language: learningLanguage,
        interface_language: interfaceLanguage,
        avatar_color: color,
        streak_days: 1,
      });
      selectStudent(created);
      navigate('/');
    } catch (e) {
      setError(e.message || 'Could not create profile');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="flex min-h-screen items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-[#FF7A00]" /></div>;
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] px-4 py-8">
      <div className="mx-auto max-w-2xl">
        <div className="text-center">
          <h1 className="font-display text-4xl font-bold text-[#FF7A00]">BHASHA-MITRA</h1>
          <p className="mt-2 text-slate-500">Vernacular learning for every child 🇮🇳</p>
        </div>

        {profiles.length > 0 && (
          <div className="mt-8">
            <h2 className="mb-3 font-display text-lg font-semibold text-[#0F172A]">Continue as</h2>
            <div className="grid gap-3 sm:grid-cols-2">
              {profiles.map((p) => (
                <button
                  key={p.id}
                  onClick={() => { selectStudent(p); navigate('/'); }}
                  className="flex items-center gap-3 rounded-2xl border-2 border-[#E2E8F0] bg-white p-4 text-left hover:border-[#FF7A00]"
                >
                  <span className="flex h-12 w-12 items-center justify-center rounded-xl text-xl font-bold text-white" style={{ backgroundColor: p.avatar_color }}>
                    {p.name.charAt(0).toUpperCase()}
                  </span>
                  <span>
                    <span className="block font-bold text-[#0F172A]">{p.name}</span>
                    <span className="block text-sm text-slate-500">{p.grade} · {LANGUAGES.find((l) => l.code === p.mother_tongue)?.native}</span>
                  </span>
                  {current?.id === p.id && <Check className="ml-auto h-5 w-5 text-[#10B981]" />}
                </button>
              ))}
            </div>
            <p className="my-6 text-center text-sm font-semibold text-slate-400">— or create a new learner —</p>
          </div>
        )}

        <div className="rounded-3xl border-2 border-[#E2E8F0] bg-white p-6 shadow-[0_8px_24px_-4px_rgba(255,122,0,0.12)]">
          <h2 className="font-display text-xl font-semibold text-[#0F172A]">New Learner</h2>

          <label className="mt-4 block text-sm font-bold text-slate-600">Child's Name</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Aarav"
            className="mt-1 w-full rounded-2xl border-2 border-[#E2E8F0] px-4 py-3 text-base outline-none focus:border-[#FF7A00]"
          />

          <label className="mt-4 block text-sm font-bold text-slate-600">Class</label>
          <div className="mt-2 flex flex-wrap gap-2">
            {['Class 1', 'Class 2', 'Class 3', 'Class 4', 'Class 5'].map((g) => (
              <button key={g} onClick={() => setGrade(g)}
                className={cn('rounded-full px-4 py-2 text-sm font-bold', grade === g ? 'bg-[#2563EB] text-white' : 'bg-[#F8FAFC] text-[#0F172A]')}>
                {g.replace('Class ', 'Class ')}
              </button>
            ))}
          </div>

          <label className="mt-5 block text-sm font-bold text-slate-600">Mother Tongue <span className="text-slate-400">(explanations will be in this language)</span></label>
          <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {LANGUAGES.map((l) => (
              <button key={l.code} onClick={() => setMotherTongue(l.code)}
                className={cn('rounded-2xl border-2 px-3 py-3 text-center', motherTongue === l.code ? 'border-[#FF7A00] bg-[#FF7A00]/5' : 'border-[#E2E8F0]')}>
                <span className="block font-display text-base font-semibold text-[#0F172A]">{l.native}</span>
                <span className="block text-xs text-slate-500">{l.name}</span>
              </button>
            ))}
          </div>

          <label className="mt-5 block text-sm font-bold text-slate-600">Learning Language</label>
          <div className="mt-2 flex flex-wrap gap-2">
            {LANGUAGES.map((l) => (
              <button key={l.code} onClick={() => setLearningLanguage(l.code)}
                className={cn('rounded-full px-4 py-2 text-sm font-bold', learningLanguage === l.code ? 'bg-[#2563EB] text-white' : 'bg-[#F8FAFC] text-[#0F172A]')}>
                {l.name}
              </button>
            ))}
          </div>

          <label className="mt-5 block text-sm font-bold text-slate-600">Interface Language</label>
          <div className="mt-2 flex flex-wrap gap-2">
            {LANGUAGES.slice(0, 4).map((l) => (
              <button key={l.code} onClick={() => setInterfaceLanguage(l.code)}
                className={cn('rounded-full px-4 py-2 text-sm font-bold', interfaceLanguage === l.code ? 'bg-[#0F172A] text-white' : 'bg-[#F8FAFC] text-[#0F172A]')}>
                {l.name}
              </button>
            ))}
          </div>

          <label className="mt-5 block text-sm font-bold text-slate-600">Avatar Colour</label>
          <div className="mt-2 flex gap-2">
            {COLORS.map((c) => (
              <button key={c} onClick={() => setColor(c)} style={{ backgroundColor: c }}
                className={cn('h-9 w-9 rounded-full', color === c && 'ring-4 ring-offset-2 ring-[#0F172A]/20')} />
            ))}
          </div>

          {error && <p className="mt-4 rounded-xl bg-[#FF7A00]/10 px-3 py-2 text-sm font-semibold text-[#FF7A00]">{error}</p>}

          <button onClick={create} disabled={saving}
            className="mt-6 flex w-full items-center justify-center gap-2 rounded-2xl bg-[#FF7A00] py-4 font-display text-lg font-bold text-white disabled:opacity-50">
            {saving ? <Loader2 className="h-5 w-5 animate-spin" /> : <Check className="h-5 w-5" />} Start Learning
          </button>
        </div>
      </div>
    </div>
  );
}