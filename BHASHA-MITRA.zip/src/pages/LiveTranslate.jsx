const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { useStudent } from '@/lib/StudentContext';
import { LANGUAGES, getLanguage } from '@/lib/languages';
import { recordAudio, uploadAudio } from '@/lib/audio';
import AudioPlayer from '@/components/AudioPlayer';
import ProcessingState from '@/components/ProcessingState';
import { Mic, Loader2, ArrowRightLeft, AlertTriangle, Volume2 } from 'lucide-react';
import { cn } from '@/lib/utils';

function Side({ label, color, fromCode, toCode, onSpoken, disabled }) {
  const [recording, setRecording] = useState(false);
  const [stage, setStage] = useState(null);
  const [transcript, setTranscript] = useState('');
  const [translation, setTranslation] = useState('');
  const [error, setError] = useState('');

  const from = getLanguage(fromCode);
  const to = getLanguage(toCode);

  const speak = async () => {
    setError(''); setRecording(true); setStage('listening');
    try {
      const blob = await recordAudio(7000);
      setStage('understanding');
      const audioUrl = await uploadAudio(blob);
      const tr = await db.functions.invoke('transcribeAudio', { audioUrl });
      const text = (tr.data?.transcript || '').trim();
      if (!text) { setError('Could not hear clearly. Try again.'); setStage(null); return; }
      setTranscript(text);
      setStage('translating');
      const res = await db.functions.invoke('translate', { text, from: from.name, to: to.name });
      setTranslation(res.data?.translation || '');
      onSpoken?.({ from: from.name, to: to.name, text, translation: res.data?.translation || '' });
    } catch (e) {
      setError(e?.name === 'NotAllowedError' ? 'Microphone permission denied.' : (e.message || 'Failed.'));
    } finally {
      setStage(null); setRecording(false);
    }
  };

  return (
    <div className="rounded-[24px] border-2 p-5" style={{ borderColor: `${color}33`, boxShadow: `0 8px 24px -4px ${color}22` }}>
      <div className="flex items-center justify-between">
        <span className="font-display text-lg font-bold" style={{ color }}>{label}</span>
        <span className="rounded-full px-3 py-1 text-xs font-bold text-white" style={{ backgroundColor: color }}>{from.native} → {to.native}</span>
      </div>

      <button onClick={speak} disabled={disabled || !!stage}
        className={cn('mt-4 flex w-full items-center justify-center gap-2 rounded-2xl py-4 font-bold text-white disabled:opacity-50', recording && 'animate-pulse')}
        style={{ backgroundColor: color }}>
        {stage ? <Loader2 className="h-5 w-5 animate-spin" /> : <Mic className="h-5 w-5" />}
        {stage === 'listening' ? 'Listening…' : stage === 'understanding' ? 'Understanding…' : stage === 'translating' ? 'Translating…' : `Speak ${from.name}`}
      </button>

      {error && <p className="mt-2 flex items-center gap-1 text-xs font-semibold text-[#FF7A00]"><AlertTriangle className="h-3 w-3" />{error}</p>}

      {transcript && (
        <div className="mt-3 rounded-2xl bg-[#F8FAFC] p-3">
          <p className="text-xs font-bold text-slate-400">SAID ({from.name})</p>
          <p className="mt-1 text-[1.0625rem] text-[#0F172A]">{transcript}</p>
        </div>
      )}
      {translation && (
        <div className="mt-2 rounded-2xl p-3" style={{ backgroundColor: `${color}11` }}>
          <p className="text-xs font-bold" style={{ color }}>TRANSLATION ({to.name})</p>
          <p className="mt-1 text-[1.0625rem] text-[#0F172A]">{translation}</p>
          <div className="mt-2"><AudioPlayer text={translation} languageCode={to.tts} label="Play" variant="ghost" /></div>
        </div>
      )}
    </div>
  );
}

export default function LiveTranslate() {
  const navigate = useNavigate();
  const { current } = useStudent();
  const [teacherFrom, setTeacherFrom] = useState('en');
  const [teacherTo, setTeacherTo] = useState('kn');
  const [studentFrom, setStudentFrom] = useState('kn');
  const [studentTo, setStudentTo] = useState('en');
  const [history, setHistory] = useState([]);

  // keep teacher/student sides mirrored
  const setTeacher = (code) => { setTeacherFrom(code); setStudentTo(code); };
  const setStudent = (code) => { setStudentFrom(code); setTeacherTo(code); };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-display text-3xl font-bold text-[#0F172A]">Live Translator 🌐</h1>
        <p className="text-slate-500">Two-way conversation between teacher and student.</p>
      </div>

      {/* Language selectors */}
      <div className="rounded-[24px] border-2 border-[#E2E8F0] bg-white p-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-bold text-slate-500">TEACHER SPEAKS</label>
            <select value={teacherFrom} onChange={(e) => setTeacher(e.target.value)} className="mt-1 w-full rounded-xl border-2 border-[#E2E8F0] px-3 py-2 text-sm font-bold outline-none">
              {LANGUAGES.map((l) => <option key={l.code} value={l.code}>{l.name} ({l.native})</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-bold text-slate-500">STUDENT SPEAKS</label>
            <select value={studentFrom} onChange={(e) => setStudent(e.target.value)} className="mt-1 w-full rounded-xl border-2 border-[#E2E8F0] px-3 py-2 text-sm font-bold outline-none">
              {LANGUAGES.map((l) => <option key={l.code} value={l.code}>{l.name} ({l.native})</option>)}
            </select>
          </div>
        </div>
        <div className="mt-2 flex items-center justify-center gap-2 text-xs font-semibold text-slate-400">
          <ArrowRightLeft className="h-4 w-4" /> Translates each way automatically
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Side label="Teacher" color="#2563EB" fromCode={teacherFrom} toCode={teacherTo}
          onSpoken={(m) => setHistory((h) => [{ role: 'Teacher', ...m }, ...h].slice(0, 20))} />
        <Side label="Student" color="#FF7A00" fromCode={studentFrom} toCode={studentTo}
          onSpoken={(m) => setHistory((h) => [{ role: 'Student', ...m }, ...h].slice(0, 20))} />
      </div>

      {history.length > 0 && (
        <div className="rounded-[24px] border-2 border-[#E2E8F0] bg-white p-5">
          <h2 className="font-display text-lg font-semibold text-[#0F172A]">Conversation history</h2>
          <div className="mt-3 space-y-2">
            {history.map((h, i) => (
              <div key={i} className="rounded-2xl bg-[#F8FAFC] p-3">
                <p className="text-xs font-bold" style={{ color: h.role === 'Teacher' ? '#2563EB' : '#FF7A00' }}>{h.role} · {h.from} → {h.to}</p>
                <p className="mt-1 text-sm text-[#0F172A]">{h.text}</p>
                <p className="text-sm font-semibold text-slate-600">{h.translation}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}