const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { useStudent } from '@/lib/StudentContext';
import { getLanguage, SUBJECTS } from '@/lib/languages';
import { Mic, Camera, Languages, Trophy, BookOpen, Sparkles, Star, ArrowRight } from 'lucide-react';

export default function Home() {
  const navigate = useNavigate();
  const { current, loading } = useStudent();
  const [continueLesson, setContinueLesson] = useState(null);
  const [continueProgress, setContinueProgress] = useState(null);
  const [todayAttempts, setTodayAttempts] = useState(0);
  const [completedToday, setCompletedToday] = useState(0);
  const [recommended, setRecommended] = useState(null);

  useEffect(() => {
    if (!current) return;
    db.analytics.track('session_started', { grade: current.grade, mother_tongue: current.mother_tongue });
    (async () => {
      try {
        const { items: progress } = await db.entities.StudentProgress.filter(
          { student_id: current.id, status: 'in_progress' },
          { sort: '-last_visited', limit: 1 }
        );
        if (progress[0]) {
          setContinueProgress(progress[0]);
          const lesson = await db.entities.Lesson.get(progress[0].lesson_id);
          setContinueLesson(lesson);
        } else {
          const { items: lessons } = await db.entities.Lesson.filter({}, { sort: 'order', limit: 1 });
          if (lessons[0]) setContinueLesson(lessons[0]);
        }
      } catch (e) { /* ignore */ }

      try {
        const start = new Date(); start.setHours(0, 0, 0, 0);
        const count = await db.entities.QuizAttempt.count({
          student_id: current.id, created_date: { $gte: start.toISOString() },
        });
        setTodayAttempts(count || 0);
      } catch (e) { /* ignore */ }

      try {
        const start = new Date(); start.setHours(0, 0, 0, 0);
        const count = await db.entities.StudentProgress.count({
          student_id: current.id, status: 'completed', updated_date: { $gte: start.toISOString() },
        });
        setCompletedToday(count || 0);
      } catch (e) { /* ignore */ }

      try {
        // Simple recommendation: lowest-scoring recent subject
        const { rows } = await db.entities.QuizAttempt.aggregate({
          query: { student_id: current.id },
          groupBy: 'subject',
          avg: 'score',
          sort: 'avg_score',
        });
        if (rows && rows[0]) {
          const { items: lessons } = await db.entities.Lesson.filter(
            { subject: rows[0].subject },
            { sort: 'order', limit: 1 }
          );
          if (lessons[0]) setRecommended({ lesson: lessons[0], subject: rows[0].subject, avg: rows[0].avg_score });
        }
      } catch (e) { /* ignore */ }
    })();
  }, [current]);

  if (loading) return <div className="py-20 text-center text-slate-400">Loading…</div>;
  if (!current) {
    return (
      <div className="py-20 text-center">
        <p className="text-slate-500">No learner selected.</p>
        <button onClick={() => navigate('/onboarding')} className="mt-4 rounded-2xl bg-[#FF7A00] px-6 py-3 font-bold text-white">Set up a learner</button>
      </div>
    );
  }

  const mt = getLanguage(current.mother_tongue);

  const quickActions = [
    { label: 'Scan & Explain', icon: Camera, color: '#FF7A00', to: '/scan' },
    { label: 'Live Translate', icon: Languages, color: '#2563EB', to: '/translate' },
    { label: 'Practice Quiz', icon: Trophy, color: '#10B981', to: '/quiz' },
    { label: 'Talk & Learn', icon: Mic, color: '#8B5CF6', to: '/talk' },
  ];

  return (
    <div className="space-y-6">
      {/* Hero banner */}
      <div className="relative overflow-hidden rounded-[24px] bg-gradient-to-br from-[#FF7A00] to-[#FF9A3D] p-6 text-white shadow-[0_8px_24px_-4px_rgba(255,122,0,0.4)] lg:p-8">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-semibold text-white/80">Namaste 🙏</p>
            <h1 className="font-display text-3xl font-bold lg:text-4xl">Hi, {current.name}! 🌟</h1>
            <p className="mt-1 text-sm text-white/90">{current.grade} · Mother Tongue: {mt.native}</p>
          </div>
          <div className="flex flex-col items-center rounded-2xl bg-white/20 px-4 py-3 backdrop-blur">
            <span className="font-display text-3xl font-bold">{current.streak_days || 1}</span>
            <span className="flex items-center gap-1 text-xs font-semibold"><Star className="h-3 w-3 fill-current" /> day streak</span>
          </div>
        </div>
        <div className="mt-5 flex flex-wrap gap-3 text-sm font-semibold">
          <span className="rounded-full bg-white/20 px-3 py-1">Today's quizzes: {todayAttempts}</span>
          <span className="rounded-full bg-white/20 px-3 py-1">Lessons done: {completedToday}</span>
        </div>
      </div>

      {/* Talk & Learn primary card */}
      <button
        onClick={() => navigate('/talk')}
        className="flex w-full items-center gap-4 rounded-[24px] border-2 border-[#E2E8F0] bg-white p-5 text-left shadow-[0_8px_24px_-4px_rgba(255,122,0,0.12)] transition hover:border-[#FF7A00] lg:p-6"
      >
        <span className="relative flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-[#FF7A00] text-white">
          <Mic className="h-7 w-7" />
          <span className="absolute inset-0 animate-ping rounded-full bg-[#FF7A00]/30" />
        </span>
        <span className="flex-1">
          <span className="block font-display text-xl font-bold text-[#0F172A]">Talk & Learn</span>
          <span className="block text-sm text-slate-500">Ask any question in your voice — get an answer in your mother tongue.</span>
        </span>
        <ArrowRight className="h-6 w-6 text-[#FF7A00]" />
      </button>

      {/* Continue learning */}
      {continueLesson && (
        <div className="rounded-[24px] border-2 border-[#E2E8F0] bg-white p-5 shadow-[0_8px_24px_-4px_rgba(37,99,235,0.12)]">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-semibold text-[#0F172A]">Continue Learning</h2>
            <span className="rounded-full bg-[#2563EB]/10 px-3 py-1 text-xs font-bold text-[#2563EB]">{continueLesson.subject}</span>
          </div>
          <button onClick={() => navigate(`/lesson/${continueLesson.id}`)} className="mt-3 flex w-full items-center gap-3 rounded-2xl bg-[#F8FAFC] p-4 text-left hover:bg-[#E2E8F0]/40">
            <BookOpen className="h-6 w-6 text-[#2563EB]" />
            <span className="flex-1">
              <span className="block font-bold text-[#0F172A]">{continueLesson.title}</span>
              <span className="block text-sm text-slate-500">{continueLesson.concept}</span>
            </span>
            <ArrowRight className="h-5 w-5 text-slate-400" />
          </button>
          {continueProgress && (
            <div className="mt-3">
              <div className="h-2 w-full overflow-hidden rounded-full bg-[#E2E8F0]">
                <div className="h-full rounded-full bg-[#2563EB]" style={{ width: continueProgress.status === 'completed' ? '100%' : '50%' }} />
              </div>
            </div>
          )}
        </div>
      )}

      {/* Quick action bento */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {quickActions.map((a) => (
          <button key={a.label} onClick={() => navigate(a.to)}
            className="flex flex-col items-start gap-2 rounded-[24px] border-2 border-[#E2E8F0] bg-white p-4 text-left transition hover:-translate-y-0.5"
            style={{ boxShadow: `0 8px 24px -4px ${a.color}22` }}>
            <span className="flex h-11 w-11 items-center justify-center rounded-2xl text-white" style={{ backgroundColor: a.color }}>
              <a.icon className="h-5 w-5" />
            </span>
            <span className="font-display text-base font-semibold text-[#0F172A]">{a.label}</span>
          </button>
        ))}
      </div>

      {/* Subjects ribbon */}
      <div>
        <h2 className="mb-3 font-display text-lg font-semibold text-[#0F172A]">Subjects</h2>
        <div className="flex gap-3 overflow-x-auto pb-2 lg:grid lg:grid-cols-5 lg:overflow-visible">
          {SUBJECTS.map((s) => (
            <button key={s.key} onClick={() => navigate(`/learn?subject=${encodeURIComponent(s.key)}`)}
              className="flex min-w-[140px] flex-col items-center gap-2 rounded-[24px] border-2 border-[#E2E8F0] bg-white p-4 lg:min-w-0">
              <span className="text-3xl">{s.icon}</span>
              <span className="font-display text-sm font-semibold text-[#0F172A]">{s.key}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Recommended practice */}
      {recommended && (
        <div className="rounded-[24px] border-2 border-dashed border-[#8B5CF6] bg-[#8B5CF6]/5 p-5">
          <div className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-[#8B5CF6]" />
            <h2 className="font-display text-lg font-semibold text-[#8B5CF6]">Recommended for you</h2>
          </div>
          <p className="mt-1 text-sm text-slate-500">More practice in {recommended.subject} will help you improve.</p>
          <button onClick={() => navigate(`/lesson/${recommended.lesson.id}`)}
            className="mt-3 flex w-full items-center justify-between rounded-2xl bg-white p-4">
            <span className="font-bold text-[#0F172A]">{recommended.lesson.title}</span>
            <span className="rounded-full bg-[#8B5CF6] px-4 py-1.5 text-sm font-bold text-white">Practice</span>
          </button>
        </div>
      )}
    </div>
  );
}